#include <stdio.h>
void hello(){
	printf("Hello World\n");
}

int main() {

	//Calling a function here
	hello();
	return 0;
}
