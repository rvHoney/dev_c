#include <stdio.h>
void text(){
	printf("Ce programme est sous license gpl.\nVous êtes autorisés à le copier.\nVous êtes autorisés à le modifier.\n");
	
}

int main() {

	//Calling a function here
	text();
	return 0;
}
